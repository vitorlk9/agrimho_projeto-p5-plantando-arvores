let truckX = 0; // posição do caminhão
let truckSpeed = 2; // velocidade do caminhão

function setup() {
 // fundo com ceú e fundo
  background(135, 206, 235); // ceú azul
  fill(34, 139, 34); // chão verde
  rect(0, height * 0.75, width, height * 0.25);
  
 // desenhar a cidade à esquerda
  drawCity();
  
  // desenhar o campo à direita
  drawField();
  
  // desenhar a estrada
  fill(50);
  rect(0, height * 0.75 - 20, width, 20);
  
  // mover caminhão
  drawTruck(truckX, height * 0.75 - 30);
  trucX += truckSpeed;
  
  // quando chegar ao campo, reiniciar a posição
  if (truckX > width + 50) {
    truckX = -100;
  }
}
  // função para desenhar cidade
function drawCity () {
  fill(150);
  // prédios
  rect(50, height * 0.75 - 150, 50, 150);
  rect(120, height * 0.75 - 200, 70, 200);
  rect(200, height * 0.75 - )